<div class="content-detached content-right">
    <div class="content-body">
        <section id="descriptioin" class="card">
            <div class="card-header">
                <h4 class="card-title"><i class="ft-user"></i>About-us History</h4>
            </div>
            <div class="card-content">
                <div class="col-md-12">
                    <form class="form form-horizontal" method="post" >
                        <div class="form-body">
                            <div class="form-group row">
                               
                                <div class="col-md-12">
                                    <label class="label-control" for="projectinput1">About Us History: <b><?= $values->history_content ?></b></label>
                                </div>
                                <div class="col-md-3">
                                    <button type="button" class="btn btn-primary cus-btn" onclick="edit()">
                                        Edit
                                    </button>
                                </div>
                            </div>
                        </div>

                    </form>
                </div>
            </div>
        </section>
    </div>
    <!--/ Description -->
</div>

<script>

    function edit(value) {
        $.get("<?= base_url('Auth/Basic_Details/edit_history') ?>/", function (data) {
            $("#modal-header").html('Edit Aboutus History');
            $("#modal-value").html(data);
            $("#myModal").modal('show');
            restart_scripts();
        });
    }

</script>