<div class="content-detached content-right">
    <div class="content-body">
        <section id="descriptioin" class="card">
            <div class="card-header">
                <h4 class="card-title"><i class="ft-eye"></i> Basic Details</h4>
            </div>
            <div class="card-content">
                <div class="col-md-12">
                    <form class="form form-horizontal" method="post" >
                        <div class="form-body">
                            <div class="form-group row">
                                <div class="col-md-4">
                                    <label class="label-control" for="projectinput1">Logo : <img src="<?= base_url($values->site_ab_logo) ?>" style="width:100px;"/></label>
                                </div>
                                <div class="col-md-4">
                                    <label class="label-control" for="projectinput1">Other Logo : <img src="<?= base_url($values->site_ab_logo_other) ?>" style="width:100px;background: #eee;"/></label>
                                </div>
                                <div class="col-md-4">
                                    <label class="label-control" for="projectinput1">FavIcon : <img src="<?= base_url($values->site_ab_icon) ?>" style="width:100px;"/></label>
                                </div>
                                <div class="col-md-4">
                                    <label class="label-control" for="projectinput1">Site Name : <b><?= $values->site_ab_site_name ?></b></label>
                                </div>
                                <div class="col-md-4">
                                    <label class="label-control" for="projectinput1">Email : <b><?= $values->site_ab_email ?></b></label>
                                </div>
                                <div class="col-md-4">
                                    <label class="label-control" for="projectinput1">Email2 : <b><?= $values->site_ab_email2 ?></b></label>
                                </div>
                                <div class="col-md-4">
                                    <label class="label-control" for="projectinput1">Contact : <b><?= $values->site_ab_contact ?></b></label>
                                </div>
                                <div class="col-md-4">
                                    <label class="label-control" for="projectinput1">Contact2 : <b><?= $values->site_ab_contact2 ?></b></label>
                                </div>
                                <div class="col-md-12">
                                    <label class="label-control" for="projectinput1">Address : <b><?= $values->site_ab_address ?></b></label>
                                </div>

                                <div class="col-md-12">
                                    <label class="label-control" for="projectinput1">Meta Keys : <b><?= $values->site_ab_meta_key ?></b></label>
                                </div>
                                <div class="col-md-12">
                                    <label class="label-control" for="projectinput1">Meta Description : <b><?= $values->site_ab_meta_content ?></b></label>
                                </div>
                                <div class="col-md-12">
                                    <label class="label-control" for="projectinput1">About Us : <b><?= $values->site_ab_about_us ?></b></label>
                                </div>
                                <div class="col-md-3">
                                    <button type="button" class="btn btn-primary cus-btn" onclick="edit()">
                                        Edit
                                    </button>
                                </div>
                            </div>
                        </div>

                    </form>
                </div>
            </div>
        </section>
    </div>
    <!--/ Description -->
</div>

<script>

    function edit(value) {
        $.get("<?= base_url('Auth/Basic_Details/edit') ?>/", function (data) {
            $("#modal-header").html('Edit Basic Details');
            $("#modal-value").html(data);
            $("#myModal").modal('show');
            restart_scripts();
        });
    }

</script>