<form class="form form-horizontal" method="post" enctype="multipart/form-data">
    <div class="form-body">
        <div class="form-group row">
            

            <div class="col-md-12">
                <label class="label-control" for="projectinput1">About Us History: </label>
                <input type="text" class="form-control" value="<?= $values->history_content ?>" name="history" required>
            </div>
            <div class="col-md-3">
                <button type="submit" class="btn btn-primary cus-btn" formaction="<?= base_url('Auth/Basic_Details/update_history/') ?><?= $values->id ?>">
                    Update
                </button>
            </div>
        </div>
    </div>

</form>
