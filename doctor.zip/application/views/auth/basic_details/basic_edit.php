<form class="form form-horizontal" method="post" enctype="multipart/form-data">
    <div class="form-body">
        <div class="form-group row">
            <div class="col-md-6">
                <label class="label-control" for="projectinput1">Logo : <img src="<?= base_url($values->site_ab_logo) ?>" style="width:20px;"/></label>
                <input type="hidden" name="old_logo" value="<?= $values->site_ab_logo ?>">
                <input type="file" class="form-control" name="logo" >
            </div>
            <div class="col-md-6">
                <label class="label-control" for="projectinput1">Other Logo : <img src="<?= base_url($values->site_ab_logo_other) ?>" style="width:20px;"/></label>
                <input type="hidden" name="old_logo_other" value="<?= $values->site_ab_logo_other ?>">
                <input type="file" class="form-control" name="logo_other" >
            </div>
            <div class="col-md-6">
                <label class="label-control" for="projectinput1">FavIcon : <img src="<?= base_url($values->site_ab_icon) ?>" style="width:20px;"/></label>
                <input type="hidden" name="old_favicon" value="<?= $values->site_ab_icon ?>">
                <input type="file" class="form-control" name="favicon" >
            </div>
            <div class="col-md-6">
                <label class="label-control" for="projectinput1">Site Name : </label>
                <input type="text" class="form-control" value="<?= $values->site_ab_site_name ?>" name="site_name" required>
            </div>
            <div class="col-md-6">
                <label class="label-control" for="projectinput1">Email :</label>
                <input type="email" class="form-control" value="<?= $values->site_ab_email ?>" name="email" required>
            </div>

             <div class="col-md-6">
                <label class="label-control" for="projectinput1">Email2 :</label>
                <input type="email" class="form-control" value="<?= $values->site_ab_email2 ?>" name="email2" required>
            </div>
            <div class="col-md-6">
                <label class="label-control" for="projectinput1">Contact : </label>
                <input type="text" onkeypress="return event.charCode >= 48 && event.charCode <= 57" minlength="10" maxlength="10" class="form-control" value="<?= $values->site_ab_contact ?>" name="contact" required>
            </div>
            <div class="col-md-6">
                <label class="label-control" for="projectinput1">Contact2 : </label>
                <input type="text" onkeypress="return event.charCode >= 48 && event.charCode <= 57" minlength="10" maxlength="10" class="form-control" value="<?= $values->site_ab_contact2 ?>" name="contact2" required>
            </div>
            <div class="col-md-12">
                <label class="label-control" for="projectinput1">Address : </label>
                <input type="text" class="form-control" value="<?= $values->site_ab_address ?>" name="address" required>
            </div>

            <div class="col-md-12">
                <label class="label-control" for="projectinput1">Meta Keys : </label>
                <input type="text" class="form-control" value="<?= $values->site_ab_meta_key ?>" name="meta_key" required>
            </div>
            <div class="col-md-12">
                <label class="label-control" for="projectinput1">Meta Description : </label>
                <input type="text" class="form-control" value="<?= $values->site_ab_meta_content ?>" name="meta_content" required>
            </div>

            <div class="col-md-12">
                <label class="label-control" for="projectinput1">About Us : </label>
                <input type="text" class="form-control" value="<?= $values->site_ab_about_us ?>" name="aboutus" required>
            </div>
            <div class="col-md-3">
                <button type="submit" class="btn btn-primary cus-btn" formaction="<?= base_url('Auth/Basic_Details/update/') ?><?= $values->site_ab_id ?>">
                    Update
                </button>
            </div>
        </div>
    </div>

</form>
