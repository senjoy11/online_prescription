<div class="content-detached content-right">
    <div class="content-body">
        <section id="descriptioin" class="card">
            <div class="card-header">
                <h4 class="card-title"><i class="ft-user"></i> Edit Patient
                   <a  class="btn btn-primary pull-right" href="<?= base_url('Auth/Patients') ?>"> View Patients </a></h4>
            </div>
            <div class="card-content">
                <div class="col-md-12">
           <form class="form form-horizontal" method="post" enctype="multipart/form-data">
                        <div class="form-body">
                            <div class="form-group row">
                             <div class="col-md-3">
                                    <label class="label-control" for="projectinput1">Patients Name :</label>
                                    <input type="text" name="ac_name" class="form-control" value="<?= $values->ac_name ?>" required>
                                </div>
                                <div class="col-md-3">
                                    <label class="label-control" for="projectinput1">Gender :</label>
                                     <select class="form-control" name="ac_sex">
                                        <option value="">Select Gender</option>
                                     <?php
                                        foreach ($department as $dep) {?>
                                        <option <?php if($values->ac_sex == 'Female' ){echo 'selected';}?> value="Female">Female</option>
                                        <option <?php if($values->ac_sex == 'Male' ){echo 'selected';}?> value="Male">Male</option>
                                       <?php }?>
                                    </select>
                                </div>
                                <div class="col-md-3">
                                    <label class="label-control" for="projectinput1">Age :</label>
                                    <input type="text" name="ac_age" onkeypress="return event.charCode >= 48 && event.charCode <= 57" minlength="1" maxlength="3" class="form-control" value="<?= $values->ac_age ?>" required>
                                </div>
                                <div class="col-md-3">
                                    <label class="label-control" for="projectinput1">Mobile :</label>
                                    <input type="text" name="ac_mobile" onkeypress="return event.charCode >= 48 && event.charCode <= 57" minlength="10" maxlength="10" class="form-control" value="<?= $values->ac_mobile ?>" required>
                                </div>
                                <div class="col-md-3">
                                    <label class="label-control" for="projectinput1">Department :</label>
                                     <select class="form-control" name="aa_id">
                                        <option value="">Select Department</option>
                                     <?php
                                        foreach ($department as $dep) {?>
                                        <option <?php if($values->aa_id == $dep->aa_id ){echo 'selected';}?> value="<?= $dep->aa_id ?>"> <?= $dep->aa_name ?> </option>
                                       <?php }?>
                                    </select>
                                </div>
                                 <div class="col-md-3">
                                    <label class="label-control" for="projectinput1">Doctor :</label>
                                     <select class="form-control" name="aa_cid">
                                       
                                     <?php
                                        foreach ($doctor as $doc) { ?>
                                        <option <?php if($values->ab_id == $doc->ab_id ){echo 'selected';}?> value="<?= $doc->ab_id ?>"><?= $doc->ab_name?> </option>
                                       <?php }?>
                                    </select>
                                </div>
                                <div class="col-md-3">
                                    <label class="label-control" for="projectinput1">Fees :</label>
                                    <input type="number" name="ac_fee" class="form-control" value="<?= $values->ac_fee ?>" required="required" readonly="readonly">
                                </div>
                                <div class="col-md-3">
                                    <label class="label-control" for="projectinput1">Address :</label>
                                    <textarea name="ac_address" class="form-control"  value="" style="resize: none;"><?= $values->ac_address;?> </textarea>
                                </div>
                                
                                <div class="col-md-3">
                                    <button type="submit" class="btn btn-primary cus-btn" formaction="<?= base_url('Auth/Patients/update/'.$values->ac_id) ?>">
                                        UPDATE
                                    </button>
                                    <a  class="btn btn-warning cus-btn" href="<?= base_url('Auth/Patients') ?>">
                                        BACK
                                    </a>
                                </div>
                            </div>
                        </div>
                    </form>
  </div>
            </div>
        </section>
      
    </div>
    <!--/ Description -->
</div>
