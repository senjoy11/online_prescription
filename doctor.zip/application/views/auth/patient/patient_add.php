<div class="content-detached content-right">
    <div class="content-body">
        <section id="descriptioin" class="card">
            <div class="card-header">
                <h4 class="card-title"><i class="ft-file"></i> Add Prescription 
                  <a  class="btn btn-primary pull-right" href="<?= base_url('Auth/Patients') ?>"> View Patients </a></h4>
            </div>
            <div class="card-content">
                <div class="col-md-12">
                    <form class="form form-horizontal" method="post" enctype="multipart/form-data">
                        <div class="form-body">
                            <div class="form-group row">
                             <div class="col-md-3">
                                    <label class="label-control" for="projectinput1">Patient Name :</label>
                                    <input type="text" name="ac_name" class="form-control" placeholder="" required>
                                </div>
                                <div class="col-md-3">
                                    <label class="label-control" for="projectinput1">Gender :</label>
                                     <select class="form-control" name="ac_sex">
                                        <option value="">Select Gender</option>
                                        <option value="Female">Female</option>
                                        <option value="Male">Male</option>
                                    </select>
                                </div>
                                <div class="col-md-3">
                                    <label class="label-control" for="projectinput1">Age :</label>
                                    <input type="number" name="ac_age" class="form-control" placeholder="Enter age" required>
                                </div>
                                <div class="col-md-3">
                                    <label class="label-control" for="projectinput1">Department :</label>
                                     <select class="form-control" name="aa_id" onchange="get_doctor(this.value)">
                                        <option value="">Select Department</option>
                                     <?php
                                        foreach ($department as $dep) {
                                        echo '<option value="' . $dep->aa_id . '">' . $dep->aa_name . '</option>';
                                        }?>
                                    </select>
                                </div>
                                 
                                 <div class="col-md-3">
                                    <label class="label-control" for="projectinput1">Doctor :</label>
                                     <select class="form-control" name="ab_id" id="doc" onchange="get_fee(this.value)">
                                        <option value="">Select Doctor</option>
                                    </select>
                                </div>

                                <div class="col-md-3">
                                    <label class="label-control" for="projectinput1">Fee :</label>
                                     <select class="form-control" name="ac_fee" id="fees" required="required" readonly="readonly">
                                        <!-- <option value="">Select Fee</option> -->
                                    </select>
                                    <small>(In Rupees)</small>
                                </div>
                                 
                                  <!-- <div class="col-md-3">
                                    <label class="label-control" for="projectinput1">Fee:</label>
                                    <input type="number" name="ac_fee" id="fees" class="form-control" required="">
                                </div> -->

                                <div class="col-md-3">
                                    <label class="label-control" for="projectinput1">Mobile No:</label>
                                    <input type="text" name="ac_mobile" onkeypress="return event.charCode >= 48 && event.charCode <= 57" minlength="10" maxlength="10" class="form-control" required="">
                                </div>
                                
                                <div class="col-md-3">
                                    <label class="label-control" for="projectinput1">Address:</label>
                                    <textarea name="ac_address" class="form-control"  placeholder="Enter Address" style="resize: none;"> </textarea>
                                </div>
                                
                                <div class="col-md-3">
                                    <button type="submit" class="btn btn-primary cus-btn" formaction="<?= base_url('Auth/Patients/insert') ?>">
                                        Save
                                    </button>
                                    <button type="button" class="btn btn-warning cus-btn" onclick="reset()">
                                        Clear
                                    </button>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </section>
      
    </div>
    <!--/ Description -->
</div>

 <script>
        function get_doctor(aa_id){
              // alert(cat_id);
             $.get("<?= base_url('Auth/Patients/get_doctor/') ?>"+aa_id, function(data,status){
                $('#doc').html(data);
            });
           
        }
</script>

<script>
        function get_fee(ab_id){
             
             $.get("<?= base_url('Auth/Patients/get_fee/') ?>"+ab_id, function(data,status){
                $('#fees').html(data);
            });
           
        }
</script>
    