<div class="content-detached content-right ps-hero hidden-print">
    <div class="content-body hidden-print">
        <section id="descriptioin" class="card">
            <div class="card-header">
                <h4 class="card-title"><i class="ft-edit"></i>Prescription-Slip</h4>
            </div>
            <div class="card-content">
                <div class="search-panel">
                  
                </div>
                <div class="col-md-12">
                    <table class="table table-bordered table-striped">
                            <tr>
                                <td colspan="10" style="text-align: center; font-weight: bold;">Patient Summry</td>
                            </tr>
                        </tr>
                        <tr>
                            <td>Patient Name</td>
                            <td style="font-weight: bold;"><?= $prescription->ac_name ?></td>
                            <td>Sex</td>
                            <td style="font-weight: bold;"><?= $prescription->ac_sex ?></td>
                            <td>Age</td>
                            <?php if ($prescription->ac_age > 1) {
                                $y = 'years';
                            } else{
                                $y = 'year';
                            }?>
                            <td style="font-weight: bold;"><?= $prescription->ac_age ?> <?= $y?></td>
                            <?php  $department=$this->Query->select('*','aa_department',['aa_id'=>$prescription->aa_id],'row'); ?>
                            <td>Department</td>
                            <td style="font-weight: bold;"><?= $department->aa_name ?></td>
                            <?php  $doctor=$this->Query->select('*','ab_doctor',['ab_id'=>$prescription->ab_id],'row'); ?>
                            <td>Doctor</td>
                            <td style="font-weight: bold;"><?= $doctor->ab_name ?></td>
                        </tr>
                        <tr>
                            
                            <td>Reg. No.</td>
                            <td style="font-weight: bold;"><?= $prescription->ac_registartion_no ?></td>
                            <td>Date </td>
                            <td colspan="2" style="font-weight: bold;"><?= date('d M Y',strtotime($prescription->ac_date))  ?></td>
                            <td>Address</td>
                            <td colspan="2" style="font-weight: bold;"><?= $prescription->ac_address.' Mo.'.$prescription->ac_mobile ?></td>
                             <td>Fee Paid</td>
                            <td style="font-weight: bold;">Rs.<?= $prescription->ac_fee ?> /-</td>
                        </tr>
                    </table>
                      <table class="table table-striped">
                            <tr>
                                <tr>
                                    <td colspan="6" style="text-align: center;font-weight: bold;">Prescription Detail</td>
                                </tr>
                            </tr>
                            <tr>
                                <td>Rx.</td>
                                <td colspan="3"></td>
                            </tr>
                            
                           
                     </table>

                </div>
            </div>
        </section>
        <center><button  class="btn btn-success hidden-print" onclick="print()">Print-Slip</button></center>
    </div>
    <!--/ Description -->
</div>

