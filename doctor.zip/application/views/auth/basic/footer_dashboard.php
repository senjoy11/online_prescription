<footer class="footer footer-static footer-light navbar-shadow">
    <p class="clearfix blue-grey lighten-2 text-sm-center mb-0 px-2">
      <span class="float-md-left d-block d-md-inline-block">Copyright &copy; 2019 <a class="text-bold-800 grey darken-2" href="tel:9893191291" target="_blank">Sanjay Yadav</a>, All rights reserved. </span>
      <span class="float-md-right d-block d-md-inline-blockd-none d-lg-block">Hand-crafted & Made with <i class="ft-heart pink"></i></span>
    </p>
  </footer>
<script src="<?= base_url('asset') ?>/vendors/js/vendors.min.js" type="text/javascript"></script>
  <script type="text/javascript" src="<?= base_url('asset') ?>/vendors/js/ui/jquery.sticky.js"></script>
  <script type="text/javascript" src="<?= base_url('asset') ?>/vendors/js/charts/jquery.sparkline.min.js"></script>
  <script src="<?= base_url('asset') ?>/vendors/js/forms/validation/jqBootstrapValidation.js"
  type="text/javascript"></script>
  <script src="<?= base_url('asset') ?>/vendors/js/charts/chart.min.js" type="text/javascript"></script>
  <script src="<?= base_url('asset') ?>/vendors/js/charts/raphael-min.js" type="text/javascript"></script>
  <script src="<?= base_url('asset') ?>/vendors/js/charts/morris.min.js" type="text/javascript"></script>
  <script src="<?= base_url('asset') ?>/vendors/js/charts/jvector/jquery-jvectormap-2.0.3.min.js"
  type="text/javascript"></script>
  <script src="<?= base_url('asset') ?>/vendors/js/charts/jvector/jquery-jvectormap-world-mill.js"
  type="text/javascript"></script>
  <script src="<?= base_url('asset') ?>/data/jvector/visitor-data.js" type="text/javascript"></script>


  <script src="<?= base_url('asset') ?>/js/core/app-menu.min.js" type="text/javascript"></script>
  <script src="<?= base_url('asset') ?>/js/core/app.min.js" type="text/javascript"></script>
  <script type="text/javascript" src="<?= base_url('asset') ?>/js/scripts/ui/breadcrumbs-with-stats.min.js"></script>
  <script src="<?= base_url('asset') ?>/js/scripts/pages/dashboard-sales.min.js" type="text/javascript"></script>

</body>
</html>