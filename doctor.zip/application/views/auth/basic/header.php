<body class="horizontal-layout horizontal-menu 2-columns   menu-expanded hidden-print" data-open="hover"
      data-menu="horizontal-menu" data-col="2-columns">

    <div class="myAlert-top alert alert-success slideRightToLeft" id="success_msg">
        <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
        <strong>Success!</strong> <?= $msg[1] ?>.
    </div>
    <div class="myAlert-top alert alert-danger slideRightToLeft" id="err_msg">
        <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
        <strong>Error!</strong> <?= $msg[1] ?>.
    </div>
    <!-- fixed-top-->
    <nav class="header-navbar navbar-expand-md navbar navbar-with-menu navbar-without-dd-arrow navbar-static-top navbar-light navbar-brand-center">
        <div class="navbar-wrapper">
            <div class="navbar-header">
                <ul class="nav navbar-nav flex-row">
                    <li class="nav-item mobile-menu d-md-none mr-auto"><a class="nav-link nav-menu-main menu-toggle hidden-xs" href="#"><i class="ft-menu font-large-1"></i></a></li>
                    <li class="nav-item">
                        <a class="navbar-brand" href="#">
                            <img class="brand-logo" alt="modern admin logo" src="<?= base_url($basic_details->site_ab_logo) ?>" width="36px">
                            <h3 class="brand-text"><?= $basic_details->site_ab_site_name ?></h3>
                        </a>
                    </li>
                    <li class="nav-item d-md-none">
                        <a class="nav-link open-navbar-container" data-toggle="collapse" data-target="#navbar-mobile"><i class="la la-ellipsis-v"></i></a>
                    </li>
                </ul>
            </div>
            <div class="navbar-container content">
                <div class="collapse navbar-collapse" id="navbar-mobile">
                    <ul class="nav navbar-nav mr-auto float-left">
                        <li class="nav-item d-none d-md-block"><a class="nav-link nav-menu-main menu-toggle hidden-xs" href="#"><i class="ft-menu"></i></a></li>
                        <li class="nav-item d-none d-md-block"><a class="nav-link nav-link-expand" href="#"><i class="ficon ft-maximize"></i></a></li>
                    </ul>
                    <ul class="nav navbar-nav float-right">
                        <li class="dropdown dropdown-user nav-item">
                            <a class="dropdown-toggle nav-link dropdown-user-link" href="#" data-toggle="dropdown">
                                <span class="mr-1">Hello,
                                    <span class="user-name text-bold-700">Sanjay</span>
                                </span>
                                <span class="avatar avatar-online">
                                    <img src="<?= base_url('asset') ?>/images/image.png" style="width:36px;" alt="avatar"></span>
                            </a>
                        </li>

                        <li class="dropdown dropdown-notification nav-item">
                            <a class="nav-link nav-link-label" href="<?= base_url('Login/logout')?>"><i class="ficon ft-log-out">             </i></a>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </nav>
    <!-- ////////////////////////////////////////////////////////////////////////////-->
    <div class="header-navbar navbar-expand-sm navbar navbar-horizontal navbar-fixed navbar-dark navbar-without-dd-arrow navbar-shadow"
         role="navigation" data-menu="menu-wrapper">
        <div class="navbar-container main-menu-content" data-menu="menu-container">
            <ul class="nav navbar-nav" id="main-menu-navigation" data-menu="menu-navigation">
                <li class="dropdown nav-item" data-menu="dropdown">
                    <a class="nav-link" href="<?= base_url('Auth/Dashboard') ?>"><i class="la la-bars"></i>
                        <span>Dashboard</span>
                    </a>
                </li>
                <!--     <li class="dropdown nav-item" data-menu="dropdown"><a class="dropdown-toggle nav-link" href="#" data-toggle="dropdown"><i class="la la-home"></i><span>Order Report</span></a>
                    <ul class="dropdown-menu">
                      <li data-menu="">
                         <a class="dropdown-item" href="<?= base_url('Auth/Order') ?>" data-toggle="dropdown">All Order</a>
                      </li>
                       <li data-menu="">
                         <a class="dropdown-item" href="<?= base_url('Auth/Order/') ?>" data-toggle="dropdown">Cancel Order</a>
                       </li>
                      
                    </ul>
                </li> -->
                 <li class="dropdown nav-item" data-menu="dropdown">
                    <a class="nav-link" href="<?= base_url('Auth/Departments') ?>"><i class="la la-hospital-o"></i>
                        <span>Department</span>
                    </a>
                </li>
                <li class="dropdown nav-item" data-menu="dropdown">
                    <a class="nav-link" href="<?= base_url('Auth/Doctors') ?>"><i class="la la-medkit"></i>
                        <span>Doctors</span>
                    </a>
                </li>

                <li class="dropdown nav-item" data-menu="dropdown">
                    <a class="nav-link" href="<?= base_url('Auth/Patients') ?>"><i class="la la-hotel"></i>
                        <span>Patients</span>
                    </a>
                </li>
                <li class="dropdown nav-item" data-menu="dropdown">
                    <a class="nav-link" href="<?= base_url('Auth/Patients/add_new') ?>"><i class="la la-comment"></i>
                        <span>Create Prescription</span>
                    </a>
                </li>
               
                
                
                <!-- <li class="dropdown nav-item" data-menu="dropdown">
                    <a class="nav-link" href="<?= base_url('Auth/Basic_Details') ?>"><i class="la la-home"></i>
                        <span>Basic Details</span>
                    </a>
                    <ul class="dropdown-menu">
                        <li data-menu=""><a class="dropdown-item" href="<?= base_url('Auth/Basic_Details/history') ?>" data-toggle="dropdown">About-us History</a>
                        </li>
                        
                    </ul>
                </li> -->

            </ul>
        </div>
    </div>

    <div class="app-content content cus-page">
        <div class="content-wrapper">

     



