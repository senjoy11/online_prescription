</div>
</div>
<footer class="footer footer-static footer-light navbar-shadow hidden-print">
    <p class="clearfix blue-grey lighten-2 text-sm-center mb-0 px-2">
        <span class="float-md-left d-block d-md-inline-block">Copyright &copy; 2019 <a class="text-bold-800 grey darken-2" href="tel:9893191291" target="_blank">Sanjay Yadav</a>, All rights reserved. </span>
        <span class="float-md-right d-block d-md-inline-blockd-none d-lg-block">Hand-crafted & Made with <i class="ft-heart pink"></i></span>
    </p>
</footer>
<!-- Modal -->
<div id="myModal" class="modal fade" role="dialog">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header bg-info white">
                <h4 class="modal-title white" id="myModalLabel8"><i class="la la-gears"></i> <span id="modal-header">Basic Modal</span></h4>
                <button type="button" class="close" data-dismiss="modal">&times;</button>
            </div>
            <div class="modal-body" id="modal-value">

            </div>
        </div>

    </div>
</div>

<script src="<?= base_url('asset') ?>/vendors/js/vendors.min.js" type="text/javascript"></script>
<script src="<?= base_url('asset') ?>/vendors/js/jquery-ui.js" type="text/javascript"></script>
<script>
    $(".datepicker").datepicker({dateFormat: 'dd-mm-yy', changeMonth: true, changeYear: true});

</script>
<script type="text/javascript" src="<?= base_url('asset') ?>/vendors/js/ui/jquery.sticky.js"></script>
<script type="text/javascript" src="<?= base_url('asset') ?>/vendors/js/charts/jquery.sparkline.min.js"></script>
<script src="<?= base_url('asset') ?>/vendors/js/forms/validation/jqBootstrapValidation.js" type="text/javascript"></script>
<script src="<?= base_url('asset') ?>/vendors/js/extensions/sweetalert.min.js" type="text/javascript"></script>

<script src="<?= base_url('asset') ?>/vendors/js/extensions/jquery.raty.js" type="text/javascript"></script>
<script src="<?= base_url('asset') ?>/vendors/js/extensions/jquery.knob.min.js" type="text/javascript"></script>
<script src="<?= base_url('asset') ?>/vendors/js/extensions/wNumb.js" type="text/javascript"></script>
<script src="<?= base_url('asset') ?>/vendors/js/extensions/nouislider.min.js" type="text/javascript"></script>
<script src="<?= base_url('asset') ?>/vendors/js/charts/chart.min.js" type="text/javascript"></script>
<script src="<?= base_url('asset') ?>/vendors/js/charts/raphael-min.js" type="text/javascript"></script>
<script src="<?= base_url('asset') ?>/vendors/js/charts/morris.min.js" type="text/javascript"></script>
<script src="<?= base_url('asset') ?>/js/core/app-menu.min.js" type="text/javascript"></script>
<script src="<?= base_url('asset') ?>/js/core/app.min.js" type="text/javascript"></script>
<script src="<?= base_url('asset') ?>/js/scripts/extensions/knob.min.js" type="text/javascript"></script>
<script src="<?= base_url('asset') ?>/js/scripts/pages/content-sidebar.min.js" type="text/javascript"></script>
<script src="<?= base_url('asset') ?>/vendors/js/editors/ckeditor/ckeditor.js" type="text/javascript"></script>
<script>
    function restart_scripts() {
        $(".datepicker").datepicker({dateFormat: 'dd-mm-yy', changeMonth: true, changeYear: true});
        CKEDITOR.replace("ckeditor");
        
    }
    CKEDITOR.replace("ckeditor");
    
</script>
<?php
if ($msg[0] == 'Error') {
    echo '<script>
            $(document).ready(function () {
                setTimeout(function () {
                    $("#err_msg").addClass("show");
                }, 1000);
                setTimeout(function () {
                    $("#err_msg").removeClass("show");
                }, 5000);
            });
        </script>';
} elseif ($msg[0] == 'Success') {
    echo '<script>
            $(document).ready(function () {
                setTimeout(function () {
                    $("#success_msg").addClass("show");
                }, 500);
                setTimeout(function () {
                    $("#success_msg").removeClass("show");
                }, 5000);
            });
        </script>';
}
?>

<?php ?>

</body>
</html>