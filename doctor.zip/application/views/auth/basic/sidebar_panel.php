<div class="cus-sidebar-sticky sidebar-detached sidebar-left sidebar-sticky">
    <div class="sidebar">
        <div class="sidebar-content card d-none d-lg-block">
            <div class="card-body main-menu menu-light menu-shadow ">
                <h4 class="card-title">Software Modules</h4>
                <ul class="navigation navigation-main" id="main-menu-navigation" data-menu="menu-navigation">
                    <li class="nav-item <?= $p1 ?>"><a href="<?= base_url('Auth/Departments') ?>"><i class="la la-hand-o-right"></i><span class="menu-title">Departments</span></a></li>
                    <li class="nav-item <?= $p2 ?>"><a href="<?= base_url('Auth/Doctors') ?>"><i class="la la-hand-o-right"></i><span class="menu-title">Doctors</span></a></li>
                      <li class="nav-item <?= $p3 ?>"><a href="<?= base_url('Auth/Patients') ?>"><i class="la la-hand-o-right"></i><span class="menu-title">Patients</span></a></li>
                     <li class="nav-item <?= $p4 ?>"><a href="<?= base_url('Auth/Patients/add_new') ?>"><i class="la la-hand-o-right"></i><span class="menu-title">Prescription </span></a></li>
                     
                </ul>
            </div>
        </div>
    </div>
</div>
