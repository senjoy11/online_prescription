<!DOCTYPE html>
<html class="loading" lang="en" data-textdirection="ltr">
<head>
  <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0, minimal-ui">
  <meta name="description" content="">
  <meta name="keywords" content="">
  <meta name="author" content="Crisil Infotech">
  <title><?= $title;?></title>
  <link rel="shortcut icon" type="image/x-icon" href="<?= base_url($basic_details->site_ab_icon) ?>">
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Quicksand:300,400,500,700"  rel="stylesheet">
  <link href="https://maxcdn.icons8.com/fonts/line-awesome/1.1/css/line-awesome.min.css" rel="stylesheet">
  <link rel="stylesheet" type="text/css" href="<?= base_url('asset') ?>/css/style.css">
  <link rel="stylesheet" type="text/css" href="<?= base_url('asset') ?>/vendors/css/extensions/sweetalert.css">
  <link rel="stylesheet" type="text/css" href="<?= base_url('asset') ?>/css/vendors.min.css">
  <link rel="stylesheet" type="text/css" href="<?= base_url('asset') ?>/css/app.min.css">
  <link rel="stylesheet" type="text/css" href="<?= base_url('asset') ?>/css/core/menu/menu-types/horizontal-menu.min.css">
  <link rel="stylesheet" type="text/css" href="<?= base_url('asset') ?>/css/core/colors/palette-gradient.min.css">
  <link rel="stylesheet" type="text/css" href="<?= base_url('asset') ?>/vendors/css/charts/jquery-jvectormap-2.0.3.css">
  <link href="<?= base_url('asset') ?>/vendors/css/ui/jquery-ui.min.css" rel="stylesheet" type="text/css"/>
  <link href="https://maxcdn.icons8.com/fonts/line-awesome/1.1/css/line-awesome.min.css"

</head>