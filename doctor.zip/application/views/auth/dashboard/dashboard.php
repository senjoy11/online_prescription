<div class="app-content content">
    <div class="content-wrapper">
        <div class="content-header row">
        </div>
        <div class="content-body">
            <!-- Revenue, Hit Rate & Deals -->
            <div class="row">
                
                <div id="recent-sales" class="col-4 col-md-2">
                    <div class="card">
                        <div class="card-header" >
                        <img style="width: 48px; height: 48px;" src="<?= base_url()?>asset/images/icon/department.png">
                       </div>
                        <div class="card-content">
                        <p class="category">Total Departments</p>
                        <h3 class="title"><?= $department_count?></h3>
                        </div>
                        <div class="card-footer">
                        <div class="stats">
                        <i class="material-icons">Just updated</i>
                        </div>
                        <a class="pull-right" href="<?= base_url('Auth/Departments')?>">View Detail</a>
                    </div>
                    </div>
                </div>

                <div id="recent-sales" class="col-4 col-md-2">
                    <div class="card">
                        <div class="card-header" >
                        <img style="width: 48px; height: 48px;" src="<?= base_url()?>asset/images/icon/doctor.png">
                       </div>
                        <div class="card-content">
                        <p class="category">Total Doctors</p>
                        <h3 class="title"><?= $doctors_count?></h3>
                        </div>
                        <div class="card-footer">
                        <div class="stats">
                        <i class="material-icons">Just updated</i>
                        </div>
                        <a class="pull-right" href="<?= base_url('Auth/Doctors')?>">View Detail</a>
                    </div>
                    </div>
                </div>
                 
                  <div id="recent-sales" class="col-4 col-md-2">
                    <div class="card">
                        <div class="card-header" >
                        <img style="width: 48px; height: 48px;" src="<?= base_url()?>asset/images/icon/prescription.png">
                       </div>
                        <div class="card-content">
                        <p class="category">Total Prescriptions</p>
                        <h3 class="title"><?= $patients_count?></h3>
                        </div>
                        <div class="card-footer">
                        <div class="stats">
                        <i class="material-icons">Just updated</i>
                        </div>
                        <a class="pull-right" href="<?= base_url('Auth/Patients')?>">View Detail</a>
                    </div>
                    </div>
                </div>

                  
                
                
                
            </div>

        </div>
    </div>
</div>