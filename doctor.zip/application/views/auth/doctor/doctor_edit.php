<div class="content-detached content-right">
    <div class="content-body">
        <section id="descriptioin" class="card">
            <div class="card-header">
                <h4 class="card-title"><i class="ft-user"></i> Edit Doctor
                   <a  class="btn btn-primary pull-right" href="<?= base_url('Auth/Doctors') ?>"> View Doctor </a></h4>
            </div>
            <div class="card-content">
                <div class="col-md-12">
           <form class="form form-horizontal" method="post" enctype="multipart/form-data">
                        <div class="form-body">
                            <div class="form-group row">
                             <div class="col-md-3">
                                    <label class="label-control" for="projectinput1">Doctor Name :</label>
                                    <input type="text" name="ab_name" class="form-control" value="<?= $values->ab_name ?>" required>
                                </div>
                                <div class="col-md-3">
                                    <label class="label-control" for="projectinput1">Department :</label>
                                     <select class="form-control" name="aa_id">
                                        <option value="">Select Department</option>
                                     <?php
                                        foreach ($department as $dep) {?>
                                        <option <?php if($values->aa_id == $dep->aa_id ){echo 'selected';}?> value="<?= $dep->aa_id ?>"> <?= $dep->aa_name ?> </option>
                                       <?php }?>
                                    </select>
                                </div>
                                
                                 <div class="col-md-6">
                                    <label class="label-control" for="projectinput1">Fee:</label>
                                    <input type="number" name="ab_fee" class="form-control" required=""  value="<?= $values->ab_fee;?>">
                                        
                                </div>
                                <div class="col-md-6">
                                    <label class="label-control" for="projectinput1">Profile Image :</label>
                                     <input type="file" name="file" class="form-control" >
                                     <input type="hidden" name="old_file" value="<?= $values->ab_image ?>" class="form-control" >
                                </div>

                                 <div class="col-md-6">
                                    <label class="label-control" for="projectinput1">Front Image :</label><br>
                                     <img src="<?= base_url($values->ab_image) ?>" alt="" width="80px">
                                </div>
                                
                                 <div class="col-md-12">
                                    <label class="label-control" for="projectinput1">Doctor Description :</label>
                                    <textarea name="ab_description" id="ckeditor" placeholder="eg. About Us" required> <?= $values->ab_description;?></textarea>
                                </div>
                                <div class="col-md-3">
                                    <button type="submit" class="btn btn-primary cus-btn" formaction="<?= base_url('Auth/Doctors/update/'.$values->ab_id) ?>">
                                        UPDATE
                                    </button>
                                    <a  class="btn btn-warning cus-btn" href="<?= base_url('Auth/Doctors') ?>">
                                        BACK
                                    </a>
                                </div>
                            </div>
                        </div>
                    </form>
  </div>
            </div>
        </section>
      
    </div>
    <!--/ Description -->
</div>
