<div class="content-detached content-right">
    <div class="content-body">
        <section id="descriptioin" class="card">
            <div class="card-header">
                <h4 class="card-title"><i class="ft-user-plus"></i> Add Doctor 
                  <a  class="btn btn-primary pull-right" href="<?= base_url('Auth/Doctors') ?>"> View Doctor </a></h4>
            </div>
            <div class="card-content">
                <div class="col-md-12">
                    <form class="form form-horizontal" method="post" enctype="multipart/form-data">
                        <div class="form-body">
                            <div class="form-group row">
                             <div class="col-md-6">
                                    <label class="label-control" for="projectinput1">Doctor Name :</label>
                                    <input type="text" name="ab_name" class="form-control" placeholder="" required>
                                </div>
                                <div class="col-md-6">
                                    <label class="label-control" for="projectinput1">Department :</label>
                                     <select class="form-control" name="aa_id">
                                        <option value="">Select Department</option>
                                     <?php
                                        foreach ($department as $dep) {
                                        echo '<option value="' . $dep->aa_id . '">' . $dep->aa_name . '</option>';
                                        }?>
                                    </select>
                                </div>
                                 
                                 <div class="col-md-6">
                                    <label class="label-control" for="projectinput1">Profile Image :</label>
                                    <input type="file" name="file" class="form-control" required>
                                </div>
                               
                                 <div class="col-md-6">
                                    <label class="label-control" for="projectinput1">Fees :</label>
                                    <input type="number" name="ab_fee" class="form-control" required="">
                                </div>
                               
                                 <div class="col-md-12">
                                    <label class="label-control" for="projectinput1">Doctor Description :</label>
                                    <textarea name="ab_description" id="ckeditor" placeholder="eg. Description" required></textarea>
                                </div>
                                <div class="col-md-3">
                                    <button type="submit" class="btn btn-primary cus-btn" formaction="<?= base_url('Auth/Doctors/insert') ?>">
                                        Save
                                    </button>
                                    <button type="button" class="btn btn-warning cus-btn" onclick="reset()">
                                        Clear
                                    </button>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </section>
      
    </div>
    <!--/ Description -->
</div>
 