<div class="content-detached content-right">
    <div class="content-body">
        <section id="descriptioin" class="card">
            <div class="card-header">
                <h4 class="card-title"><i class="ft-eye"></i>View Doctors <a  class="btn btn-primary pull-right" href="<?= base_url('Auth/Doctors/add_doctor') ?>"> Add Doctor </a></h4>
            </div>
            <div class="card-content">
                <div class="search-panel">
                    <form class="form form-horizontal">
                        <div class="col-md-3">
                            <label>Search :</label>
                        </div>
                        <div class="col-md-6 no-padding">
                            <input type="text" id="projectinput1" value="<?php echo $this->input->get('search') != '' ? urldecode($this->input->get('search')) : ''; ?>" class="form-control"  placeholder="eg. Dr Anmol" name="search" required>
                        </div>
                        <div class="col-md-3 no-padding">
                            <button type="submit" class="btn btn-primary cus-btn1" formaction="<?= base_url('Auth/Doctors/search') ?>">
                                <i class="la la-search"></i>
                            </button>
                            <a class="btn btn-warning cus-btn1" href="<?= base_url('Auth/Doctors') ?>">
                                <i class="la la-refresh"></i>
                            </a>
                        </div>

                        <div class="clearfix"></div>
                    </form>
                </div>
                <div class="col-md-12">
                    <table class="table table-bordered table-striped">
                        <thead>
                            <tr>
                                <th>S.No.</th>
                                <th>Doctors Name</th>
                                <th>Image</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            $n = 1;
                            foreach ($values as $value) {
                                ?>
                                <tr>
                                    <td><?= $n++ ?></td>
                                    <td><?=$value->ab_name ?></td>
                                    <td><img src="<?= base_url($value->ab_image) ?>" style="width:50px;height:50px;" class="rounded-circle" /></td>
                                    <td>
                                        <a class="btn btn-info cus-btn2" href="<?= base_url('Auth/Doctors/edit/'. $value->ab_id) ?>" >
                                            <i class="la la-pencil"></i>
                                        </a>
                                        <a class="btn btn-danger cus-btn2" onclick="delete_data('<?= $value->ab_id ?>')" href="#">
                                            <i class="la la-close"></i>
                                        </a>
                                    </td>
                                </tr>
                                <?php } ?>
                        </tbody>
                        <tfoot>
                            <tr>
                                <td colspan="8">
                                    <?= $links ?>
                                </td>
                            </tr>
                        </tfoot>
                    </table>
                </div>
            </div>
        </section>
    </div>
    <!--/ Description -->
</div>

<script>

     function delete_data(value) {

        swal({
            title: "Are you sure?",
            text: "Once deleted, you will not be able to recover this entry!",
            icon: "warning",
            buttons: true,
            dangerMode: true,
        })
                .then((willDelete) => {
                    if (willDelete) {
                        $.ajax({url: "<?= base_url('Auth/Doctors/delete') ?>/" + value, success: function (result) {
                                swal("Poof! Your imaginary file has been deleted!", {
                                    icon: "success",
                                });
                                location.reload();
                            }});
                    } else {
                        swal("Your Entry is not deleted!");
                    }
                });
    }
</script>