<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Departments extends CI_Controller {
    public function __construct() {
        parent::__construct();
        $this->load->library('basic');
        $this->basic->loader();
        $this->basic->checklogin();
    }
public function index($per_page = 30) {
        $this->basic->header(1, 'Departments');
        $data['basic_details'] = $this->Query->select('*', 'site_ab_basic_details', ['site_ab_id' => site_ab_id()], 'row');
        /* PAGINATE */
        $total = $this->Query->select('*', 'aa_department', '', 'count');
        $paginate = $this->basic->create_links('Departments/index/', $total, $per_page, 5);
        $data['links'] = $paginate['links'];

        $data['values'] = $total = $this->Query->select('*', 'aa_department', '', 'result', ['aa_ordering'=>'asc'], [$paginate['per_page'], $paginate['page']]);
        /* END PAGINATE */
        $this->load->view('auth/department/department_add_view', $data);
        $this->basic->footer('admin', 1);
    }

    public function search($per_page = 30) {
        $this->basic->header(1, 'admin');
        $search_value = $this->input->get('search');
        $data['basic_details'] = $this->Query->select('*', 'site_ab_basic_details', ['site_ab_id' => site_ab_id()], 'row');
        $search = '(aa_name like"%' . $search_value . '%" )';
        /* PAGINATE */
        $total = $this->Query->select('*', 'aa_department', $search, 'count');
        $paginate = $this->basic->create_links('Departments/index/', $total, $per_page, 5);
        $data['links'] = $paginate['links'];
        $data['values'] = $total = $this->Query->select('*','aa_department', $search, 'result', '', [$paginate['per_page'], $paginate['page']]);
        /* END PAGINATE */
        $this->load->view('auth/department/department_add_view', $data);
        $this->basic->footer('admin', 1);
    }

     public function insert_department() {
      
        $array = [
                    'aa_name' => $this->input->post('name'),
                    'aa_ordering' => $this->input->post('ordering'),
                    'aa_status' => $this->input->post('status')
                   ];
        $qry = $this->Query->insert('aa_department', $array);
        if ($qry == TRUE) {
            set_msg('Department Added Successfully', 'S');
        } else {
            set_msg('Error Occured. Try Again!!', 'E');
        }
        $this->basic->refer();
    }
     public function edit_department($ce_id) {
        $data['values'] =  $this->Query->select('*', 'aa_department', ['aa_id' => $ce_id], 'row');
        $this->load->view('auth/department/department_edit', $data);
    }
    public function update_department($ce_id) {
       
        $array = [
                    'aa_name' => $this->input->post('name'),
                    'aa_ordering' => $this->input->post('ordering'),
                    'aa_status' => $this->input->post('status')
                ];

        $qry = $this->Query->update('aa_department', ['aa_id' => $ce_id], $array);
        if ($qry == TRUE) {
            set_msg('Department Type Updated Successfully', 'S');
        } else {
            set_msg('Error Occured. Try Again!!', 'E');
        }
        $this->basic->refer();
    }
    public function delete_department($ce_id) {
         
        $array = [
                  'aa_id' => $ce_id
                 ];
        $qry = $this->Query->delete('aa_department', $array);
        if ($qry == TRUE) {
            set_msg('Department Deleted Successfully', 'S');
        } else {
            set_msg('Error Occured. Try Again!!', 'E');
        }
        $this->basic->refer();
    }



}?>