<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Dashboard extends CI_Controller
{
    public function __construct()
    {
         parent::__construct();
         $this->load->library('basic');
         $this->basic->loader();
         $this->basic->checklogin();
    }

    public function index()
    {
        $this->basic->header(1,'Dashboard');
        $data['basic_details']=$this->Query->select('*','site_ab_basic_details',['site_ab_id' =>site_ab_id()],'row');
        $data['doctors_count']=$this->Query->select('*','ab_doctor','','count');
        $data['department_count']=$this->Query->select('*','aa_department','','count');
        $data['patients_count']=$this->Query->select('*','ac_patient','','count');
        $this->load->view('auth/dashboard/dashboard',$data);
        $this->basic->footer_dashboard();
    }
}
?>