<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Doctors extends CI_Controller {
    public function __construct() {
        parent::__construct();
        $this->load->library('basic');
        $this->basic->loader();
        $this->basic->checklogin();
    }

    public function index($per_page = 30) {
        $this->basic->header(2, 'admin');
        $data['basic_details'] = $this->Query->select('*', 'site_ab_basic_details', ['site_ab_id' => site_ab_id()], 'row');
        /* PAGINATE */
        $total = $this->Query->select('*', 'ab_doctor', '', 'count');
        $paginate = $this->basic->create_links('Doctors/index/', $total, $per_page, 5);
        $data['links'] = $paginate['links'];
        $data['values'] = $total = $this->Query->select('*', 'ab_doctor', '', 'result', ['ab_id'=>'desc'], [$paginate['per_page'], $paginate['page']]);
    
        /* END PAGINATE */
        $this->load->view('auth/doctor/doctor_view_delete', $data);
        $this->basic->footer('admin', 2);
    }

    public function add_doctor($per_page = 30) {
        $this->basic->header(2, 'admin');
        $data['basic_details'] = $this->Query->select('*', 'site_ab_basic_details', ['site_ab_id' => site_ab_id()], 'row');
        /* PAGINATE */
        $total = $this->Query->select('*', 'ab_doctor', '', 'count');
        $paginate = $this->basic->create_links('Doctors/index/', $total, $per_page, 5);
        $data['links'] = $paginate['links'];
        $data['values'] = $total = $this->Query->select('*', 'ab_doctor', '', 'result', '', [$paginate['per_page'], $paginate['page']]);
        $data['department']  = $this->Query->select('*', 'aa_department',['aa_status'=>'Enabled'],'result');
        $this->load->view('auth/doctor/doctor_add', $data);
        $this->basic->footer('admin', 2);
    }
     
    public function search($per_page = 30) {
        $this->basic->header(2, 'admin');
        $search_value = $this->input->get('search');
        $data['basic_details'] = $this->Query->select('*', 'site_ab_basic_details', ['site_ab_id' => site_ab_id()], 'row');
        $search = '(ab_name like"%' . $search_value . '%" )';
        /* PAGINATE */
        $total = $this->Query->select('*', 'ab_doctor', $search, 'count');
        $paginate = $this->basic->create_links('Doctors/index/', $total, $per_page, 5);
        $data['links'] = $paginate['links'];
        $data['values'] = $total = $this->Query->select('*','ab_doctor', $search, 'result', '', [$paginate['per_page'], $paginate['page']]);
        /* END PAGINATE */
        $this->load->view('auth/doctor/doctor_view_delete', $data);
        $this->basic->footer('admin', 2);
    }
     
    public function insert() {
        $image ="";
          if ($_FILES['file']['name']!="") {
            $image = $this->basic->file_upload('Doctors', 'file');
        }
         
        $array = [
                    'ab_image' => $image,
                    'ab_name' => $this->input->post('ab_name'),
                    'aa_id' => $this->input->post('aa_id'),
                    'ab_fee' => $this->input->post('ab_fee'),
                    'ab_description' => $this->input->post('ab_description')
                   ];
            
        $last_id = $this->Query->insert('ab_doctor', $array,true);
        if($last_id) {
            set_msg('Doctor Added Successfully', 'S');
        } else {
            set_msg('Error Occured. Try Again!!', 'E');
        }
        redirect(base_url('Auth/Doctors'));
    }

    public function edit($ce_id) {
         $this->basic->header(2, 'admin');
         $data['values'] = $total = $this->Query->select('*', 'ab_doctor', ['ab_id' => $ce_id], 'row');
         $data['department']  = $this->Query->select('*', 'aa_department',['aa_status'=>'Enabled'],'result');
         
         
         $this->load->view('auth/doctor/doctor_edit', $data);
         $this->basic->footer('admin', 2);
    }
    public function update($ce_id) {
        $image =$this->input->post('old_file');
         if($_FILES['file']['name']!="") {
             $image = $this->basic->file_upload('Doctors', 'file');
             $imagedata  = $this->Query->select('ab_image', 'ab_doctor', ['ab_id' => $ce_id], 'row');
             unlink($imagedata->ab_image);
        }
       
        $array = [
                    'ab_image' => $image,
                    'ab_name' => $this->input->post('ab_name'),
                    'aa_id' => $this->input->post('aa_id'),
                    'ab_fee' => $this->input->post('ab_fee'),
                    'ab_description' => $this->input->post('ab_description')
                    ];
        $qry = $this->Query->update('ab_doctor', ['ab_id' => $ce_id], $array);
        if ($qry == TRUE) {
            set_msg('Doctor Updated Successfully', 'S');
        } else {
            set_msg('Error Occured. Try Again!!', 'E');
        }
      redirect(base_url('Auth/Doctors'));
    }
    
     public function delete($ab_id) 
     {
            $qry = $this->Query->delete('ab_doctor',[ 'ab_id' => $ab_id]);
        if ($qry == TRUE) 
        {
            set_msg('Doctor Deleted Successfully', 'S');
        } else {
            set_msg('Error Occured. Try Again!!', 'E');
        }
        $this->basic->refer();
    }
}?>