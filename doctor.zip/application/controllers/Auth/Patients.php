<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Patients extends CI_Controller {
    public function __construct() {
        parent::__construct();
        $this->load->library('basic');
        $this->basic->loader();
        $this->basic->checklogin();
    }
     public function index($per_page = 30) 
     {
        $this->basic->header(3, 'admin');
        $data['basic_details'] = $this->Query->select('*', 'site_ab_basic_details', ['site_ab_id' => site_ab_id()], 'row');
        /* PAGINATE */
        $total = $this->Query->select('*', 'ac_patient', '', 'count');
        $paginate = $this->basic->create_links('Patients/index/', $total, $per_page, 5);
        $data['links'] = $paginate['links'];
        $data['values'] = $total = $this->Query->select('*', 'ac_patient', '', 'result', ['ac_id'=>'desc'], [$paginate['per_page'], $paginate['page']]);
        $this->load->view('auth/patient/patient_view_delete', $data);
        $this->basic->footer('admin', 3);
    }

    public function view_prescription($ac_id)
    {
        $this->basic->header(4, 'admin');
        $data['prescription']=$this->Query->select('*','ac_patient',['ac_id'=>$ac_id],'row');
        $this->load->view('auth/patient/prescription_slip', $data);
        $this->basic->footer('admin', 4);
    } 
    public function add_new($per_page = 30) {
        $this->basic->header(4, 'admin');
        $data['basic_details'] = $this->Query->select('*', 'site_ab_basic_details', ['site_ab_id' => site_ab_id()], 'row');
        /* PAGINATE */
        $total = $this->Query->select('*', 'ac_patient', '', 'count');
        $paginate = $this->basic->create_links('Patients/index/', $total, $per_page, 5);
        $data['links'] = $paginate['links'];
        $data['values'] = $total = $this->Query->select('*', 'ac_patient', '', 'result', '', [$paginate['per_page'], $paginate['page']]);
        $data['department']  = $this->Query->select('*', 'aa_department',['aa_status'=>'Enabled'],'result');
        
        /* END PAGINATE */
        $this->load->view('auth/patient/patient_add', $data);
        $this->basic->footer('admin', 4);
    }
    
    public function search($per_page = 30) {
        $this->basic->header(3, 'admin');
        $search_value = $this->input->get('search');
        $data['basic_details'] = $this->Query->select('*', 'site_ab_basic_details', ['site_ab_id' => site_ab_id()], 'row');
        $search = '(ac_name like"%' . $search_value . '%" )';
        /* PAGINATE */
        $total = $this->Query->select('*', 'ac_patient', $search, 'count');
        $paginate = $this->basic->create_links('Patients/index/', $total, $per_page, 5);
        $data['links'] = $paginate['links'];
        $data['values'] = $total = $this->Query->select('*','ac_patient', $search, 'result', '', [$paginate['per_page'], $paginate['page']]);
        /* END PAGINATE */
        $this->load->view('auth/patient/patient_view_delete', $data);
        $this->basic->footer('admin', 3);
    }
     public function get_doctor($aa_id){
        $doctor_data = $this->Query->select('*','ab_doctor',['aa_id'=>$aa_id],'result');
        echo '<option value="">Select Doctor</option>';
        foreach($doctor_data as $doc)
        {

            echo '<option value="'.$doc->ab_id.'">'.$doc->ab_name.'</option>';
        }
    }
    public function get_fee($ab_id)
    {
        $fee_data = $this->Query->select('*','ab_doctor',['ab_id'=>$ab_id],'row');
        echo '<option value="'.$fee_data->ab_fee.'">'.$fee_data->ab_fee.'</option>';
    }
    public function insert() {
        
          
        $array = [
                    
                    'ac_name' => $this->input->post('ac_name'),
                    'ac_sex' => $this->input->post('ac_sex'),
                    'ac_age' => $this->input->post('ac_age'),
                    'ac_mobile' => $this->input->post('ac_mobile'),
                    'ac_address' => $this->input->post('ac_address'),
                    'aa_id' => $this->input->post('aa_id'),
                    'ab_id' => $this->input->post('ab_id'),
                    'ac_date' =>date('Y-m-d'),
                    'ac_registartion_no' => mt_rand(10000,99999),
                    'ac_fee' => $this->input->post('ac_fee')
                   ];
        $last_id = $this->Query->insert('ac_patient', $array,true);
       
               
        if($last_id) {
            set_msg('Prescription Added Successfully', 'S');
        } else {
            set_msg('Error Occured. Try Again!!', 'E');
        }
        redirect(base_url('Auth/Patients'));
    }
    public function edit($ac_id) {
         $this->basic->header(3, 'admin');
         $data['values'] = $total = $this->Query->select('*', 'ac_patient', ['ac_id' => $ac_id], 'row');
         $data['department']  = $this->Query->select('*', 'aa_department',['aa_status'=>'Enabled'],'result');
          $data['doctor']  = $this->Query->select('*', 'ab_doctor','','result');
         $this->load->view('auth/patient/patient_edit', $data);
         $this->basic->footer('admin', 3);
    }
    public function update($ce_id) {
        
        $array = [
                    
                    'ac_name' => $this->input->post('ac_name'),
                    'ac_sex' => $this->input->post('ac_sex'),
                    'ac_age' => $this->input->post('ac_age'),
                    'ac_mobile' => $this->input->post('ac_mobile'),
                    'ac_address' => $this->input->post('ac_address'),
                    'aa_id' => $this->input->post('aa_id'),
                    'ab_id' => $this->input->post('ab_id'),
                    'ac_fee' => $this->input->post('ac_fee')
                   ];
        $qry = $this->Query->update('ac_patient', ['ac_id' => $ce_id], $array);
        if ($qry == TRUE) {
            set_msg('Prescription Updated Successfully', 'S');
        } else {
            set_msg('Error Occured. Try Again!!', 'E');
        }
      redirect(base_url('Auth/Patients'));
    }
     
   
     public function delete($ac_id) {
        $deleted = $this->Query->delete('ac_patient',[ 'ac_id' => $ac_id]);
        if ($deleted == TRUE) {
            set_msg('Prescription Deleted Successfully', 'S');
            }
            else 
            {
            set_msg('Error Occured. Try Again!!', 'E');
            }
        $this->basic->refer();
    }
}?>