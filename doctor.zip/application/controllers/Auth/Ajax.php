<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Ajax extends CI_Controller
{
    public function __construct()
    {
         parent::__construct();
         $this->load->library('basic');
         $this->basic->loader();
         $this->basic->checklogin();
    }

    public function index()
    {
        $this->basic->header(1,'Academic Year');
        $data['basic_details']=$this->Query->select('*','cc_basic_details',['cc_id' => $this->session->userdata('newschool_id')],'row');
        $this->load->view('auth/academic_year/academic_year_add_view_delete',$data);
        $this->basic->footer();
    }
}
?>