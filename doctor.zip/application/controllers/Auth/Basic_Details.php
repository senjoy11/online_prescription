<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Basic_Details extends CI_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->library('basic');
        $this->basic->loader();
        $this->basic->checklogin();
    }

    public function index($per_page = 30) {
        $this->basic->header(1, 'website');
        $data['values'] = $this->Query->select('*', 'site_ab_basic_details', ['site_ab_id' => 1], 'row');
        $this->load->view('auth/basic_details/basic_view', $data);
        $this->basic->footer('website', 1);
    }
    public function history($per_page = 30) {
        $this->basic->header(1, 'website');
        $data['values'] = $this->Query->select('*', 'history', ['id' => 1], 'row');
        $this->load->view('auth/basic_details/history', $data);
        $this->basic->footer('website', 1);
    }

    public function edit() {
        $data['values'] = $total = $this->Query->select('*', 'site_ab_basic_details', ['site_ab_id' => 1], 'row');
        $this->load->view('auth/basic_details/basic_edit', $data);
    }
     public function edit_history() {
        $data['values'] = $total = $this->Query->select('*', 'history', ['id' => 1], 'row');
        $this->load->view('auth/basic_details/history_edit', $data);
    }
    

    public function update($ce_id) {
        $logo =$this->input->post('old_logo');
        $logo_other =$this->input->post('old_logo_other');
        $favicon =$this->input->post('old_favicon');
        if ($_FILES) {
            if($_FILES['logo']['name']!=''){
                $logo = $this->basic->file_upload('basic', 'logo');
            }
            if($_FILES['logo_other']['name']!=''){
                $logo_other = $this->basic->file_upload('basic', 'logo_other');
            }
            if($_FILES['favicon']['name']!=''){
                $favicon = $this->basic->file_upload('basic', 'favicon');
            }
        }
        $array = [
            'site_ab_site_name' => $this->input->post('site_name'),
            'site_ab_meta_key' =>$this->input->post('meta_key'),
            'site_ab_meta_content' => $this->input->post('meta_content'),
            'site_ab_email' => $this->input->post('email'),
            'site_ab_email2' => $this->input->post('email2'),
            'site_ab_contact' => $this->input->post('contact'),
            'site_ab_contact2' => $this->input->post('contact2'),
            'site_ab_address' => $this->input->post('address'),
            'site_ab_about_us' => $this->input->post('aboutus'),
            'site_ab_logo' => $logo,
            'site_ab_logo_other' => $logo_other,
            'site_ab_icon' => $favicon
        ];
        $qry = $this->Query->update('site_ab_basic_details',['site_ab_id' => $ce_id], $array);
        if ($qry == TRUE) {
            set_msg('Details Updated Successfully', 'S');
        } else {
            set_msg('Error Occured. Try Again!!', 'E');
        }
        $this->basic->refer();
    }
    public function update_history($ce_id) {
      
        $array = [
            'history_content' => $this->input->post('history'),
            'date'=>date('Y-m-d')
                ];
        $qry = $this->Query->update('history',['id' => $ce_id], $array);
        if ($qry == TRUE) {
            set_msg('Details Updated Successfully', 'S');
        } else {
            set_msg('Error Occured. Try Again!!', 'E');
        }
        $this->basic->refer();
    }
    

}

?>