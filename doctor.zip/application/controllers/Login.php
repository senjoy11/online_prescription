<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Login extends CI_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->library('basic');
        $this->basic->loader();
    }

    function checklogin() {
        if ($this->session->userdata('newsite_user') != NULL && $this->session->userdata('newsite_id') != NULL) {
            redirect(base_url('Dashboard'));
        }
    }

    public function index() {
        $this->checklogin();
        $data['basics'] = $this->Query->select('*', 'site_ab_basic_details', '', 'row');
        $data['msg'] = $this->session->flashdata('msg');
        $this->load->view('auth/login/login', $data);
    }

    public function verifylogin() {
        $admin = $this->Query->select('*', 'site_aa_admin_users', ['site_aa_username' => $this->input->post('username'), 'site_aa_password' => $this->input->post('password')], 'count');
        if ($admin > 0) {

            $admin = $this->Query->select('*', 'site_aa_admin_users', ['site_aa_username' => $this->input->post('username'), 'site_aa_password' => $this->input->post('password')], 'row');
            $this->session->set_userdata('newsite_user', $admin->site_aa_user_id);
            $this->session->set_userdata('newsite_id', $admin->site_ab_id);
            $this->session->set_userdata('newsite_usertype', $admin->site_aa_type);

            set_msg("Logged in Successfully");
            redirect(base_url('Auth/Dashboard'));
        } else {
            $this->session->unset_userdata('newsite_user');
            $this->session->unset_userdata('newsite_id');
            $this->session->unset_userdata('newsite_usertype');
            set_msg("Username or Password Mismatch");
            redirect($this->agent->referrer());
        }
    }

    public function logout() {
        $this->session->unset_userdata('newsite_user');
        $this->session->unset_userdata('newsite_id');
        $this->session->unset_userdata('newsite_usertype');
        set_msg("User Logout Successfully",'S');
        redirect(base_url('Login'));
    }

}

?>