<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

function send_sms($msg, $to) {
    $msg = urlencode($msg);
    $to = $to;
    //$response = file_get_contents('http://prioritysms.tulsitainfotech.com/api/mt/SendSMS?user=ipskidz&password=helloIPS&senderid=IPSKID&channel=Trans&DCS=8&flashsms=0&number='.$to.'&text='.$msg.'&route=15');
    $rsponse = file_get_contents('http://sms.crisil.xyz/api/send_http.php?authkey=401dcc547f3a1a4b53f3a957d57bf397&mobiles=' . $to . '&message=' . $msg . '&sender=SUNRIS&route=B');
    return true;
}

//function basics($var = "") {
//    $CI = get_instance();
//    $CI->otherdb = $CI->load->database();
//    $CI->load->model('Query');
//    $res = $CI->Query->select('*', 'basic_details', ['id' => '2'], 'row');
//    if ($var != '') {
//        return $res->$var;
//    } else {
//        return $res;
//    }
//}
//
//function get_session($admin_id) {
//    $CI = get_instance();
//    $CI->load->model('Query');
//    $res = $CI->Query->select('*', 'school_session', ['admin_id' => $admin_id, 'status' => 'Active'], 'row');
//    return $res->session;
//}

function set_msg($msg, $type = 'E') {
    if ($type == 'S') {
        $type = 'Success';
    } elseif ($type == 'E') {
        $type = 'Error';
    }
    $CI = get_instance();
    $CI->load->library('session');
    $CI->session->set_flashdata('msg', array($type, $msg));
}

function site_ab_id() {
    $CI = get_instance();
    $CI->load->library('session');
    return $CI->session->userdata('newsite_id');
}

function admin() {
    $CI = get_instance();
    $CI->load->library('session');
    return $CI->session->userdata('newsite_id');
}

function refer($link='') {
    $CI = get_instance();
    $CI->load->library('user_agent');
    if($link!=''){
        $link = $CI->user_agent->referrer();
    }
    redirect($link);
}

function convert_date($date = '') {
    $date = explode('-', $date);
    return $ndate = $date[2] . '-' . $date[1] . '-' . $date[0];
}