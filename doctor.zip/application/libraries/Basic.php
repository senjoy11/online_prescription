<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Basic {

    var $CI;

    public function __construct($params = array()) {
        $this->CI = & get_instance();
        $this->CI->load->helper('url');
        $this->CI->config->item('base_url');
        $this->CI->load->database();
        $this->CI->load->model('Query');
        date_default_timezone_set('Asia/Kolkata');
    }

    public function loader() {
        $this->CI->load->library(array('session', 'user_agent'));
        $this->CI->load->helper(array('url', 'form', 'file'));
        $this->CI->load->model('Query');
    }

    function checklogin() {
        $this->CI->load->library('session');
        $chk = $this->CI->Query->select('*', 'site_ab_basic_details', ['site_ab_id' => $this->CI->session->userdata('newsite_id')], 'count');
        if ($chk != 1) {
            redirect(base_url('auth/Login'));
        }
    }

    function header($page = 1, $pagename = "", $pagetitle = "Prescription-Admin", $show_header = "yes") {
        for ($i = 1; $i <= 100; $i++) {
            if ($i == $page) {
                $data['p' . $i] = 'class="active"';
            } else {
                $data['p' . $i] = '';
            }
        }
        $data['msg'] = $this->CI->session->flashdata('msg');
        $data['page'] = $pagename;
        $data['title'] = $pagetitle;
        $data['basic_details'] = $this->CI->Query->select('*', 'site_ab_basic_details', ['site_ab_id' => $this->CI->session->userdata('newsite_id')], 'row');

        $this->CI->load->view('auth/basic/head', $data);
        $this->CI->load->view('auth/basic/header', $data);
    }

    function footer($sidebar = '',$page='1') {
        for ($i = 1; $i <= 20; $i++) {
            if ($i == $page) {
                $data['p' . $i] = 'open';
            } else {
                $data['p' . $i] = '';
            }
        }
        if ($sidebar == 'admin') {
            $this->CI->load->view('auth/basic/sidebar_panel',$data);
        }elseif ($sidebar == 'website') {
            $this->CI->load->view('auth/basic/sidebar_web',$data);
        }
        $this->CI->load->view('auth/basic/footer');
    }

    function footer_dashboard() {
        $this->CI->load->view('auth/basic/footer_dashboard');
    }

    function refer() {
        redirect($this->CI->agent->referrer());
    }

    function flash($msg = '') {
        $this->CI->session->set_flashdata('msg', $msg);
    }

    function clean($string) {
        $string1 = str_replace(' ', '-', $string); // Replaces all spaces with hyphens.
        return preg_replace('/[^A-Za-z0-9\-]/', '', $string1); // Removes special chars.
    }

    public function file_upload($file_path, $file_name) {
        $new_name = '';
        $new_name = mt_rand(111111, 999999) . $file_name;
        $config['file_name'] = $new_name;
        $config['upload_path'] = 'asset/site_img/' . $file_path;
        // $config['allowed_types']  = '*';
        $config['allowed_types'] = 'jpeg|jpg|png|pdf|docx ';
        //  $config['max_size'] = 100;
        $this->CI->load->library('upload', $config);
        $this->CI->upload->initialize($config);
        if (!$this->CI->upload->do_upload($file_name)) {
            $error = $this->CI->upload->display_errors();
            $new_name = '';
            return $error;
            exit;
        } else {
            $upload_data = $this->CI->upload->data();
            $new_name = '';
            return $config['upload_path'] . '/' . $upload_data['file_name'];
        }
    }

    public function do_pagination($url, $segment, $total, $per_page = 10, $qry = '', $qry2 = '') {
        $config = array();
        $config["base_url"] = $url;
        $config["total_rows"] = $total;
        $config["per_page"] = $per_page;
        $config["uri_segment"] = $segment;
        $config["num_links"] = 5;
        $config['reuse_query_string'] = FALSE;
        $config['full_tag_open'] = '<ul class="pagination">';
        $config['full_tag_close'] = '</ul>';
        $config['first_tag_open'] = '<li>';
        $config['first_tag_close'] = '</li>';
        $config['prev_link'] = '&laquo';
        $config['prev_tag_open'] = '<li class="prev">';
        $config['prev_tag_close'] = '</li>';
        $config['next_link'] = '&raquo';
        $config['next_tag_open'] = '<li id="1">';
        $config['next_tag_close'] = '</li>';
        $config['last_tag_open'] = '<li>';
        $config['last_tag_close'] = '</li>';
        $config['cur_tag_open'] = '<li class="active"><a href="#" >';
        $config['cur_tag_close'] = '</a></li>';
        $config['num_tag_open'] = '<li>';
        $config['num_tag_close'] = '</li>';
        $config['page_query_string'] = FALSE;
//        $config['suffix'] = '?search=' . $qry;
        $config['reuse_query_string'] = TRUE;
//        if (count($_GET) > 0)
//            $config['suffix'] = '?' . http_build_query($_GET, '', "&");
        $this->CI->pagination->initialize($config);
        return $page = ($this->CI->uri->segment($segment)) ? $this->CI->uri->segment($segment) : 0;
    }

    public function create_links($url = "", $total, $per_page = 10, $segment) {
        $url = base_url('Auth/' . $url . '/' . $per_page);
        $limit = $per_page;
        $page = $this->do_pagination($url, $segment, $total, $limit);
        return $array = array(
            'total_rec' => $total,
            'num_records' => $per_page,
            'per_page' => $per_page,
            'page' => $page,
            'links' => $this->CI->pagination->create_links()
        );
    }

}
