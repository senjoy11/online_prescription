-- phpMyAdmin SQL Dump
-- version 4.2.7.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Mar 30, 2019 at 07:32 AM
-- Server version: 5.5.39
-- PHP Version: 5.4.31

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `prescription`
--

-- --------------------------------------------------------

--
-- Table structure for table `aa_department`
--

CREATE TABLE IF NOT EXISTS `aa_department` (
`aa_id` int(11) NOT NULL,
  `aa_name` varchar(100) NOT NULL,
  `aa_ordering` int(11) NOT NULL,
  `aa_status` varchar(100) NOT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=19 ;

--
-- Dumping data for table `aa_department`
--

INSERT INTO `aa_department` (`aa_id`, `aa_name`, `aa_ordering`, `aa_status`) VALUES
(7, 'Radiology', 1, 'Enabled'),
(8, 'Physical-Therapy', 2, 'Enabled'),
(9, 'Orthopedic', 3, 'Enabled'),
(10, 'Oncology', 4, 'Enabled'),
(11, 'Anaesthesia', 5, 'Enabled'),
(12, 'Cardiac Surgery', 6, 'Enabled'),
(13, 'Cardiology', 7, 'Enabled'),
(14, 'Dental', 8, 'Enabled'),
(15, 'Dermatology', 9, 'Enabled'),
(16, 'ENT', 10, 'Enabled'),
(17, 'Gastroenterology', 11, 'Enabled'),
(18, 'Kidney', 12, 'Enabled');

-- --------------------------------------------------------

--
-- Table structure for table `ab_doctor`
--

CREATE TABLE IF NOT EXISTS `ab_doctor` (
`ab_id` int(11) NOT NULL,
  `aa_id` int(11) NOT NULL,
  `ab_name` varchar(300) NOT NULL,
  `ab_description` text NOT NULL,
  `ab_image` text NOT NULL,
  `ab_fee` float NOT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=13 ;

--
-- Dumping data for table `ab_doctor`
--

INSERT INTO `ab_doctor` (`ab_id`, `aa_id`, `ab_name`, `ab_description`, `ab_image`, `ab_fee`) VALUES
(11, 16, 'Sahil', '<p>Ear Nose Tongue</p>\r\n', 'asset/site_img/Doctors/357755file.jpg', 500),
(12, 14, 'Mona', '<p>abc xyz</p>\r\n', 'asset/site_img/Doctors/229850file.jpg', 1000);

-- --------------------------------------------------------

--
-- Table structure for table `ac_patient`
--

CREATE TABLE IF NOT EXISTS `ac_patient` (
`ac_id` int(11) NOT NULL,
  `ab_id` int(11) NOT NULL,
  `aa_id` int(11) NOT NULL,
  `ac_registartion_no` varchar(100) NOT NULL,
  `ac_name` varchar(200) NOT NULL,
  `ac_fee` varchar(100) NOT NULL,
  `ac_sex` varchar(300) NOT NULL,
  `ac_age` varchar(50) NOT NULL,
  `ac_mobile` varchar(50) NOT NULL,
  `ac_address` text NOT NULL,
  `ac_date` date NOT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=11 ;

--
-- Dumping data for table `ac_patient`
--

INSERT INTO `ac_patient` (`ac_id`, `ab_id`, `aa_id`, `ac_registartion_no`, `ac_name`, `ac_fee`, `ac_sex`, `ac_age`, `ac_mobile`, `ac_address`, `ac_date`) VALUES
(9, 11, 16, '31150', 'Chandrashekhar', '500', 'Male', '25', '9893191291', ' bhopal', '2019-03-29'),
(10, 12, 14, '88911', 'Archana', '1000', 'Female', '23', '7547888744', ' Bhopal', '2019-03-30');

-- --------------------------------------------------------

--
-- Table structure for table `site_aa_admin_users`
--

CREATE TABLE IF NOT EXISTS `site_aa_admin_users` (
`site_aa_user_id` bigint(20) NOT NULL,
  `site_aa_username` varchar(50) NOT NULL,
  `site_aa_password` varchar(600) NOT NULL,
  `site_ab_id` int(11) NOT NULL,
  `site_aa_status` varchar(20) NOT NULL,
  `site_aa_type` varchar(30) NOT NULL,
  `site_aa_name` varchar(50) NOT NULL,
  `site_aa_image` text NOT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `site_aa_admin_users`
--

INSERT INTO `site_aa_admin_users` (`site_aa_user_id`, `site_aa_username`, `site_aa_password`, `site_ab_id`, `site_aa_status`, `site_aa_type`, `site_aa_name`, `site_aa_image`) VALUES
(1, 'admin', 'admin', 1, 'Active', 'Admin', 'Ravi', '');

-- --------------------------------------------------------

--
-- Table structure for table `site_ab_basic_details`
--

CREATE TABLE IF NOT EXISTS `site_ab_basic_details` (
`site_ab_id` int(11) NOT NULL,
  `site_ab_site_name` varchar(100) NOT NULL,
  `site_ab_meta_key` text NOT NULL,
  `site_ab_meta_content` text NOT NULL,
  `site_ab_email` varchar(100) NOT NULL,
  `site_ab_contact` varchar(100) NOT NULL,
  `site_ab_email2` varchar(30) NOT NULL,
  `site_ab_contact2` varchar(50) NOT NULL,
  `site_ab_address` varchar(100) NOT NULL,
  `site_ab_logo` varchar(100) NOT NULL,
  `site_ab_logo_other` varchar(200) NOT NULL,
  `site_ab_icon` text NOT NULL,
  `site_ab_about_us` text NOT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `site_ab_basic_details`
--

INSERT INTO `site_ab_basic_details` (`site_ab_id`, `site_ab_site_name`, `site_ab_meta_key`, `site_ab_meta_content`, `site_ab_email`, `site_ab_contact`, `site_ab_email2`, `site_ab_contact2`, `site_ab_address`, `site_ab_logo`, `site_ab_logo_other`, `site_ab_icon`, `site_ab_about_us`) VALUES
(1, 'Prescription-Online', 'Prescriptio-Online', 'Prescriptio-Online', 'prescription-online@gmail.com', '9893154444', 'prescription-online@gmail.com', '9874545555', 'Bhopal', 'asset/site_img/basic/301192logo.png', 'asset/site_img/basic/573391logo_other.png', 'asset/site_img/basic/340030favicon.png', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed vel lectus eu felis semper finibus ac eget ipsum. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Etiam vulputate id justo quis facilisis.');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `aa_department`
--
ALTER TABLE `aa_department`
 ADD PRIMARY KEY (`aa_id`);

--
-- Indexes for table `ab_doctor`
--
ALTER TABLE `ab_doctor`
 ADD PRIMARY KEY (`ab_id`);

--
-- Indexes for table `ac_patient`
--
ALTER TABLE `ac_patient`
 ADD PRIMARY KEY (`ac_id`);

--
-- Indexes for table `site_aa_admin_users`
--
ALTER TABLE `site_aa_admin_users`
 ADD PRIMARY KEY (`site_aa_user_id`);

--
-- Indexes for table `site_ab_basic_details`
--
ALTER TABLE `site_ab_basic_details`
 ADD PRIMARY KEY (`site_ab_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `aa_department`
--
ALTER TABLE `aa_department`
MODIFY `aa_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=19;
--
-- AUTO_INCREMENT for table `ab_doctor`
--
ALTER TABLE `ab_doctor`
MODIFY `ab_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=13;
--
-- AUTO_INCREMENT for table `ac_patient`
--
ALTER TABLE `ac_patient`
MODIFY `ac_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=11;
--
-- AUTO_INCREMENT for table `site_aa_admin_users`
--
ALTER TABLE `site_aa_admin_users`
MODIFY `site_aa_user_id` bigint(20) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `site_ab_basic_details`
--
ALTER TABLE `site_ab_basic_details`
MODIFY `site_ab_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
